Install environment
```bash
pip install -r requirements.txt
```
Crawl news yourself:
 - Delete 2 folders: data/crawl_data and data/news_vnexpress
 - Run command `python crawl_news.py` to crawl data from vnexpress
 - Run command `python build_data.py` to format the crawled data
